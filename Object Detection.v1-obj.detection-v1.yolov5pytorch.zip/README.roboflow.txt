
Object Detection - v1 obj.detection-v1
==============================

This dataset was exported via roboflow.ai on June 12, 2022 at 4:33 AM GMT

It includes 131 images.
Accessories are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 500x500 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Random rotation of between -20 and +20 degrees
* Random exposure adjustment of between -30 and +30 percent
* Random Gaussian blur of between 0 and 1.5 pixels
* Salt and pepper noise was applied to 8 percent of pixels


